{{ config(
    materialized='table'
) }}

WITH customer_campaigns AS (
    SELECT 
        mc.customer_id,
        CAST(mc.campaign_date AS DATE) AS campaign_date,
        mc.campaign_name,
        mc.channel,
        mc.response,
        mc.conversion,
        mc.campaign_cost,
        mc.attributed_revenue,
        dc.first_subscription_date,
        
        -- Time between campaign and subscription  
        DATE_DIFF(CAST(dc.first_subscription_date AS DATE), CAST(mc.campaign_date AS DATE), DAY) AS days_to_conversion,
        
        -- Campaign sequence
        ROW_NUMBER() OVER (PARTITION BY mc.customer_id ORDER BY CAST(mc.campaign_date AS DATE)) AS campaign_sequence,
        
        -- First touch / last touch flags
        CASE WHEN ROW_NUMBER() OVER (PARTITION BY mc.customer_id ORDER BY CAST(mc.campaign_date AS DATE)) = 1 
             THEN TRUE ELSE FALSE END AS is_first_touch,
        CASE WHEN ROW_NUMBER() OVER (PARTITION BY mc.customer_id ORDER BY CAST(mc.campaign_date AS DATE) DESC) = 1 
             THEN TRUE ELSE FALSE END AS is_last_touch
    FROM {{ ref('marketing_campaigns') }} mc
    JOIN {{ ref('dim_customers') }} dc 
      ON mc.customer_id = dc.customer_id
    WHERE CAST(mc.campaign_date AS DATE) <= CAST(dc.first_subscription_date AS DATE)
),

attribution_weights AS (
    SELECT 
        *,
        -- Time decay attribution (recent campaigns get more credit)
        CASE 
            WHEN days_to_conversion <= 7 THEN 0.5
            WHEN days_to_conversion <= 30 THEN 0.3  
            WHEN days_to_conversion <= 90 THEN 0.15
            ELSE 0.05
        END AS time_decay_weight,
        
        -- Position-based attribution (first and last touch get more credit)
        CASE 
            WHEN is_first_touch OR is_last_touch THEN 0.4
            ELSE 0.2 / NULLIF(campaign_sequence - 1, 0) -- Distribute remaining 20% among middle touches
        END AS position_weight
    FROM customer_campaigns
    WHERE days_to_conversion >= 0 AND days_to_conversion <= 365 -- Valid attribution window
)

SELECT 
    customer_id,
    campaign_date,
    campaign_name,
    channel,
    response,
    conversion,
    campaign_cost,
    attributed_revenue,
    days_to_conversion,
    campaign_sequence,
    is_first_touch,
    is_last_touch,
    time_decay_weight,
    position_weight,
    
    -- Attributed revenue calculations
    attributed_revenue * time_deca_*_
