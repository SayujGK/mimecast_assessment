{{ config(
    materialized='table'
) }}

WITH customer_activities AS (
    SELECT
        s.customer_id,
        MIN(s.activity_date) AS first_activity_date,
        MAX(s.activity_date) AS last_activity_date,
        COUNT(*) AS total_activities,
        SUM(s.duration_minutes) AS total_duration_minutes,
        
        -- Count activity types
        SUM(CASE WHEN s.activity_type = 'Demo' THEN 1 ELSE 0 END) AS demos_count,
        SUM(CASE WHEN s.activity_type = 'Proposal Sent' THEN 1 ELSE 0 END) AS proposals_count,
        SUM(CASE WHEN s.activity_type = 'Negotiation' THEN 1 ELSE 0 END) AS negotiations_count,
        SUM(CASE WHEN s.activity_type = 'Closing Call' THEN 1 ELSE 0 END) AS closing_calls_count,
        
        -- Count positive outcomes
        SUM(CASE WHEN s.outcome = 'Positive' THEN 1 ELSE 0 END) AS positive_outcomes,
        
        -- First sales rep (assumes same rep for first activity)
        ARRAY_AGG(s.sales_rep ORDER BY s.activity_date ASC LIMIT 1)[OFFSET(0)] AS sales_rep
    FROM {{ ref('sales_activities') }} s
    GROUP BY s.customer_id
),

sales_with_metrics AS (
    SELECT
        ca.*,
        
        -- Sales cycle in days
        DATE_DIFF(ca.last_activity_date, ca.first_activity_date, DAY) AS sales_cycle_days,
        
        -- Success rate
        SAFE_DIVIDE(ca.positive_outcomes, ca.total_activities) AS success_rate,
        
        -- Activities per day
        SAFE_DIVIDE(ca.total_activities, DATE_DIFF(ca.last_activity_date, ca.first_activity_date, DAY) + 1) AS activities_per_day,
        
        -- Average activity duration
        SAFE_DIVIDE(ca.total_duration_minutes, ca.total_activities) AS avg_activity_duration,
        
        -- Converted flag: customer exists in dim_customers
        CASE WHEN dc.customer_id IS NOT NULL THEN TRUE ELSE FALSE END AS converted
    FROM customer_activities ca
    LEFT JOIN {{ ref('dim_customers') }} dc
        ON ca.customer_id = dc.customer_id
)

SELECT *
FROM sales_with_metrics
