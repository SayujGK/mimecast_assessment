{{ config(
    materialized='table'
) }}

WITH subscription_with_prev AS (
    SELECT
        s.*,
        LAG(s.plan_type) OVER (PARTITION BY s.customer_id ORDER BY s.start_date) AS previous_plan_type,
        LAG(s.seats) OVER (PARTITION BY s.customer_id ORDER BY s.start_date) AS previous_seats,
        LAG(s.monthly_value) OVER (PARTITION BY s.customer_id ORDER BY s.start_date) AS previous_monthly_value,
        LAG(s.start_date) OVER (PARTITION BY s.customer_id ORDER BY s.start_date) AS previous_event_date
    FROM {{ ref('customer_subscriptions') }} s
),

subscription_with_changes AS (
    SELECT
        s.subscription_id,
        s.customer_id,
        CAST(s.start_date AS DATE) AS event_date,
        EXTRACT(YEAR FROM s.start_date) AS event_year,
        EXTRACT(MONTH FROM s.start_date) AS event_month,
        s.plan_type AS plan_type,
        s.previous_plan_type,
        s.seats AS seat_count,
        s.previous_seats,
        s.monthly_value AS monthly_value,
        s.previous_monthly_value,
        s.status AS subscription_status,
        s.change_reason,

        CASE
            WHEN s.change_reason = 'New Customer' THEN 'Acquisition'
            WHEN s.change_reason IN ('Churned','Customer Churn') THEN 'Churn'
            WHEN s.change_reason = 'Upgrade Plan' THEN 'Plan_Upgrade'
            WHEN s.change_reason = 'Downgrade Plan' THEN 'Plan_Downgrade'
            WHEN s.change_reason = 'Add Seats' THEN 'Seat_Expansion'
            WHEN s.change_reason = 'Remove Seats' THEN 'Seat_Contraction'
            ELSE 'Other'
        END AS event_type,
        

        COALESCE(s.monthly_value - s.previous_monthly_value, 0) AS mrr_change,
        COALESCE(s.seats - s.previous_seats, 0) AS seat_change,
        COALESCE(DATE_DIFF(CAST(s.start_date AS DATE), CAST(s.previous_event_date AS DATE), DAY), 0) AS days_since_prior_event
    FROM subscription_with_prev s
)

SELECT *
FROM subscription_with_changes
