{{ config(
    materialized='table'
) }}

WITH subscription_stability AS (
    SELECT 
        customer_id,
        -- Subscription tenure score (0-25 points)
        LEAST(tenure_days / 10, 25) AS tenure_score,
        
        -- Plan progression score (0-20 points) 
        CASE current_plan
            WHEN 'Enterprise' THEN 20
            WHEN 'Professional' THEN 15  
            WHEN 'Starter' THEN 10
            ELSE 0
        END AS plan_score,
        
        -- Subscription changes frequency (0-15 points)
        CASE 
            WHEN total_subscriptions = 1 THEN 15  -- Stable
            WHEN total_subscriptions <= 3 THEN 10 -- Some changes
            WHEN total_subscriptions <= 5 THEN 5  -- Many changes
            ELSE 0 -- Very unstable
        END AS stability_score
    FROM {{ ref('dim_customers') }}
    WHERE lifecycle_stage != 'Churned'
),

recent_expansion_activity AS (
    SELECT 
        customer_id,
        COUNT(CASE WHEN event_type IN ('Seat_Expansion', 'Plan_Upgrade') THEN 1 END) AS expansion_events,
        COUNT(CASE WHEN event_type IN ('Seat_Contraction', 'Plan_Downgrade') THEN 1 END) AS contraction_events,
        SUM(CASE WHEN mrr_change > 0 THEN mrr_change ELSE 0 END) AS expansion_mrr,
        SUM(CASE WHEN mrr_change < 0 THEN ABS(mrr_change) ELSE 0 END) AS contraction_mrr
    FROM {{ ref('fact_subscription_events') }}
    WHERE CAST(event_date AS DATE) >= DATE_SUB(CURRENT_DATE(), INTERVAL 12 MONTH)
    GROUP BY customer_id
),

expansion_score_calc AS (
    SELECT 
        customer_id,
        -- Expansion momentum score (0-20 points)
        CASE 
            WHEN expansion_events > contraction_events AND expansion_mrr > contraction_mrr THEN 20
            WHEN expansion_events >= contraction_events THEN 15
            WHEN expansion_events > 0 THEN 10
            WHEN contraction_events = 0 THEN 5
            ELSE 0
        END AS expansion_score
    FROM recent_expansion_activity
),

support_engagement AS (
    SELECT 
        customer_id,
        COUNT(*) AS total_tickets,
        AVG(CASE WHEN satisfaction_score IS NOT NULL THEN satisfaction_score END) AS avg_satisfaction,
        COUNT(CASE WHEN priority IN ('High', 'Critical') THEN 1 END) AS high_priority_tickets,
        AVG(CASE WHEN resolution_hours IS NOT NULL THEN resolution_hours END) AS avg_resolution_hours
    FROM {{ ref('support_tickets') }}
    WHERE CAST(created_date AS DATE) >= DATE_SUB(CURRENT_DATE(), INTERVAL 6 MONTH)
    GROUP BY customer_id
),

support_score_calc AS (
    SELECT 
        customer_id,
        -- Support health score (0-20 points)
        CASE 
            WHEN avg_satisfaction >= 4.5 AND high_priority_tickets = 0 THEN 20
            WHEN avg_satisfaction >= 4.0 AND high_priority_tickets <= 1 THEN 15
            WHEN avg_satisfaction >= 3.0 AND high_priority_tickets <= 2 THEN 10
            WHEN avg_satisfaction >= 2.0 OR high_priority_tickets <= 3 THEN 5
            ELSE 0
        END AS support_score
    FROM support_engagement
)

SELECT 
    ss.customer_id,
    ss.tenure_score,
    ss.plan_score, 
    ss.stability_score,
    COALESCE(es.expansion_score, 5) AS expansion_score, -- Default neutral score
    COALESCE(su.support_score, 15) AS support_score,    -- Default good score if no tickets
    
    -- Total health score (0-100)
    ss.tenure_score + ss.plan_score + ss.stability_score + 
    COALESCE(es.expansion_score, 5) + COALESCE(su.support_score, 15) AS total_health_score,
    
    -- Health categories
    CASE 
        WHEN ss.tenure_score + ss.plan_score + ss.stability_score + 
             COALESCE(es.expansion_score, 5) + COALESCE(su.support_score, 15) >= 80 THEN 'Healthy'
        WHEN ss.tenure_score + ss.plan_score + ss.stability_score + 
             COALESCE(es.expansion_score, 5) + COALESCE(su.support_score, 15) >= 60 THEN 'At Risk'
        WHEN ss.tenure_score + ss.plan_score + ss.stability_score + 
             COALESCE(es.expansion_score, 5) + COALESCE(su.support_score, 15) >= 40 THEN 'High Risk'
        ELSE 'Critical'
    END AS health_category,
    
    CURRENT_DATE() AS calculated_date

FROM subscription_stability ss
LEFT JOIN expansion_score_calc es ON ss.customer_id = es.customer_id  
LEFT JOIN support_score_calc su ON ss.customer_id = su.customer_id
