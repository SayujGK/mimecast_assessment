{{ config(
    materialized='table'
) }}

WITH customer_base AS (
    SELECT DISTINCT 
        customer_id,
        MIN(start_date) AS first_subscription_date,
        MAX(CASE WHEN status = 'Active' THEN start_date END) AS last_active_date,
        COUNT(DISTINCT subscription_id) AS total_subscriptions
    FROM {{ ref('customer_subscriptions') }}
    GROUP BY customer_id
),

customer_current_state AS (
    SELECT 
        s.customer_id,
        s.plan_type AS current_plan,
        s.seats AS current_seats,
        s.monthly_value AS current_mrr,
        s.status AS current_status,
        s.start_date AS current_subscription_start
    FROM {{ ref('customer_subscriptions') }} s
    INNER JOIN (
        SELECT 
            customer_id, 
            MAX(start_date) AS max_start
        FROM {{ ref('customer_subscriptions') }}
        GROUP BY customer_id
    ) latest 
    ON s.customer_id = latest.customer_id 
    AND s.start_date = latest.max_start
)

SELECT 
    cb.customer_id,
    cb.first_subscription_date,
    cb.last_active_date,
    cb.total_subscriptions,
    cs.current_plan,
    cs.current_seats,
    cs.current_mrr,
    cs.current_status,
    cs.current_subscription_start,
    
    -- Customer lifecycle stage
    CASE 
        WHEN cs.current_status = 'Churned' THEN 'Churned'
        WHEN cs.current_status = 'Active' AND cb.total_subscriptions = 1 THEN 'New'
        WHEN cs.current_status = 'Active' AND cb.total_subscriptions > 1 THEN 'Expanded'
        ELSE 'Inactive'
    END AS lifecycle_stage,
    
    -- Tenure calculation
    DATE_DIFF(CURRENT_DATE(), cb.first_subscription_date, DAY) AS tenure_days,
    
    -- Effective dates for SCD Type 2
    cb.first_subscription_date AS effective_start_date,
    DATE '9999-12-31' AS effective_end_date,
    TRUE AS is_current

FROM customer_base cb
JOIN customer_current_state cs 
    ON cb.customer_id = cs.customer_id
