with calendar as (
    select
        day as date_id
    from unnest(
        generate_date_array('2022-01-01', '2025-12-31')  -- adjust range as needed
    ) as day
)

select
    date_id,
    extract(day from date_id) as day,
    extract(month from date_id) as month,
    format_date('%B', date_id) as month_name,
    extract(quarter from date_id) as quarter,
    extract(year from date_id) as year,
    extract(dayofweek from date_id) as weekday, -- Sunday=1
    format_date('%A', date_id) as weekday_name,
    case when extract(dayofweek from date_id) in (1,7) then true else false end as is_weekend,
    case when extract(day from date_id) = 1 then true else false end as is_month_start,
    case when extract(day from date_id) = extract(day from last_day(date_id)) then true else false end as is_month_end
from calendar
